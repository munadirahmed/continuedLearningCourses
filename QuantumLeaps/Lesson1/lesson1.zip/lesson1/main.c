
int main() {
    int counter = 0; 
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    ++counter;
    
    return 0;
}
