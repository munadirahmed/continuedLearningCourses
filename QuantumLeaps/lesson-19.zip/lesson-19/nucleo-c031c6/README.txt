This directory contains embedded code for the STM32 NUCLEO-C031C6
board. This code is then used to build ET tests for this board.
See also the examples/ directory, make_nucleo-l152re makefiles.
