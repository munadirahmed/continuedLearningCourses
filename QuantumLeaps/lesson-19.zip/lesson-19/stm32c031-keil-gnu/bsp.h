#ifndef BSP_H_
#define BSP_H_

void BSP_init(void);

void BSP_led4On(void);
void BSP_led4Off(void);

void BSP_led5On(void);
void BSP_led5Off(void);

void BSP_delay(int volatile iter);

#endif // BSP_H_
