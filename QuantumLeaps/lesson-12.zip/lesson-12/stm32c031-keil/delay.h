#ifndef __DELAY_H__
#define __DELAY_H__

void delay(int volatile iter);

#endif // __DELAY_H__